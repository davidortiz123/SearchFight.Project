﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entities;

namespace winSearchFight.Client
{
    public partial class frmCreateSearchEngine : Form
    {
        public frmCreateSearchEngine()
        {
            InitializeComponent();
        }

        // Use global variable "Static" to be used in different window forms.
        public static SearchEngines searchEngines = new SearchEngines();
        private void btnCreateNew_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtNameCreate.Text.Trim()))
            {
                searchEngines.searchEngines.Add(new SearchEngine(txtNameCreate.Text));
                loadListBoxContent();
                txtNameCreate.Text = "";
                txtNameCreate.Focus();
                MessageBox.Show("Saved successfully");
            }
            else
            {
                txtNameCreate.Text = "";
                txtNameCreate.Focus();
                MessageBox.Show("Incorrect Search Name");
            }            
        }

        public void loadListBoxContent()
        {
            lbxContentSearch.Enabled = false;
            lbxContentSearch.SelectionMode = SelectionMode.None;
            lbxContentSearch.DataSource = getListNames();
        }
        public List<string> getListNames()
        {
            List<string> strings = (from o in searchEngines.searchEngines select o.Name.ToString()).ToList();
            return strings;
        }

        private void frmCreateSearchEngine_Load(object sender, EventArgs e)
        {
            loadListBoxContent();
        }
    }
}
