﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entities;

namespace winSearchFight.Client
{
    public partial class frmUpdateSearchEngine : Form
    {
        public frmUpdateSearchEngine()
        {
            InitializeComponent();
        }
        
        SearchEngines searchEngines = new SearchEngines();

        public void loadCombo()
        {
            // Clear comboBox 
            cboSearchEngine.DataSource = null;
            cboSearchEngine.Items.Clear();
            // Prepare items to combo
            var bindingSource1 = new BindingSource();
            bindingSource1.DataSource = searchEngines.searchEngines;
            cboSearchEngine.DataSource = bindingSource1.DataSource;

            cboSearchEngine.DisplayMember = "Name";
            cboSearchEngine.ValueMember = "Name";
        }
        private void frmMaintenance_Load(object sender, EventArgs e)
        {
            loadCombo();
            txtSearch.Enabled = false;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            //// If comboBox item is selected as "Create new one"
            //if (cboSearchEngine.SelectedIndex == 1)
            //{
            //    searchEngines.Add(new SearchEngine(txtSearch.Text));
            //    txtSearch.Enabled = false;
            //    MessageBox.Show("Item added sucessfully");
            //}
            //else
            //{
            //    MessageBox.Show("Need to select 'Create new one'");
            //}
            //loadCombo(); 
        }

        private void cboSearchEngine_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboSearchEngine.SelectedIndex == 1)
            {
                txtSearch.Enabled = true;
            }
        }
    }
}
