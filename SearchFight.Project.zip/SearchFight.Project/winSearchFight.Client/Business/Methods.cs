﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace winSearchFight.Client
{
    public class Methods
    {
        public SearchEngines searchEngines = new SearchEngines();
        // ... Create new Random object.
        Random random = new Random();   
        public string getSearchResult(string word)
        {
            string[] numberWords = word.Split(' ');
            int countWords = numberWords.Length;
            string maxSearchWinner = string.Empty;
            int maxCounting = 0;
            int maxCounting1 = 0;
            int maxCounting2 = 0;
            int maxCont = 0;
            int maxCont1 = 0;
            int maxCont2 = 0;
            string textContent = string.Empty;

            if(numberWords.Any(x => string.IsNullOrEmpty(x)))
            {
                return textContent = "-1";
            }

            // Check if the word search is surrounded by quotation marks []
            if (word.StartsWith("\"") && word.EndsWith("\""))
            {
                textContent = "Word Search: " + word;

                textContent = textContent + "\r\n";

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    // Assign value to search object property for amount randomly
                    frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 = random.Next(10000, 100000);
                }
                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    // Check if the search result value is the maximun from all search engines
                    if (frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 > maxCounting)
                    {
                        maxCounting = frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1;
                        maxCont = i;
                    }
                }
                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {   // Concatenate name search engines
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Name + " | ";
                }

                textContent = textContent + "\r\n";

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    // Concatenate search engines results
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 + " | ";
                }

                textContent = textContent + "\r\n" + "\r\n";

                textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[maxCont].Name + " winner: " + word;
                word = textContent;
                
                maxCounting = 0;
                maxCont = 0;
            }

            // Check if there are two words in one searching
            else if (countWords == 2)
            {
                textContent = string.Empty;               

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    // Assign value to search object property for amount randomly
                    frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 = random.Next(10000, 100000);
                    frmCreateSearchEngine.searchEngines.searchEngines[i].Counting2 = random.Next(20000, 50000);
                }

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    // Check if the search result value is the maximun from all search engines for first word
                    if (frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 > maxCounting1)
                    {
                        maxCounting1 = frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1;
                        maxCont1 = i;
                    }
                }

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    // Check if the search result value is the maximun from all search engines for second word
                    if (frmCreateSearchEngine.searchEngines.searchEngines[i].Counting2 > maxCounting2)
                    {
                        maxCounting2 = frmCreateSearchEngine.searchEngines.searchEngines[i].Counting2;
                        maxCont2 = i;
                    }
                }

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Name + " | ";
                }

                textContent = "Word Search: " + numberWords[0] + "\r\n" + textContent + "\r\n";

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 + " | ";
                }

                textContent = textContent + "\r\n" + "\r\n";
                textContent = textContent + "Word Search: " + numberWords[1] + "\r\n";

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Name + " | ";
                }

                textContent = textContent + "\r\n";

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Counting2 + " | ";
                }                

                textContent = textContent + "\r\n" + "\r\n";

                textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[maxCont1].Name + " winner: " + numberWords[0] +
                "\r\n" + frmCreateSearchEngine.searchEngines.searchEngines[maxCont2].Name + " winner: " + numberWords[1];
                
                maxCounting1 = 0;
                maxCounting2 = 0;
            }
            // Check if there is one search word
            else if (countWords == 1)
            {
                textContent = string.Empty;   

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    // Assign value to search object property for amount randomly
                    frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 = random.Next(10000, 100000);
                }

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    if (frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 > maxCounting)
                    {
                        maxCounting = frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1;
                        maxCont = i;
                    }
                }

                textContent = "Word Search: " + word;
                textContent = textContent + "\r\n";

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Name + " | ";
                }

                textContent = textContent + "\r\n";

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 + " | ";
                }

                textContent = textContent + "\r\n" + "\r\n";

                textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[maxCont].Name + " winner: " + word;
                word = textContent;

                maxCounting = 0;
                maxCont = 0;
            }
            else
            {
                // Error result
                return "-1";
            }

            // Common result Success
            return textContent;
        }
    }
}
