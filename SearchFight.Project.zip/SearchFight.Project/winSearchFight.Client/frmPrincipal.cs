﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winSearchFight.Client
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sEARCHENGINEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCreateSearchEngine formMant = new frmCreateSearchEngine();
            formMant.ShowDialog();
        }

        private void sEARCHWORDSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSearching formSearc = new frmSearching();
            formSearc.ShowDialog();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
