﻿namespace winSearchFight.Client
{
    partial class frmCreateSearchEngine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.btnCreateNew = new System.Windows.Forms.Button();
            this.txtNameCreate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbxContentSearch = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(81, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Create Search Engines";
            // 
            // btnCreateNew
            // 
            this.btnCreateNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateNew.Location = new System.Drawing.Point(42, 352);
            this.btnCreateNew.Name = "btnCreateNew";
            this.btnCreateNew.Size = new System.Drawing.Size(337, 34);
            this.btnCreateNew.TabIndex = 8;
            this.btnCreateNew.Text = "Save";
            this.btnCreateNew.UseVisualStyleBackColor = true;
            this.btnCreateNew.Click += new System.EventHandler(this.btnCreateNew_Click);
            // 
            // txtNameCreate
            // 
            this.txtNameCreate.Location = new System.Drawing.Point(42, 120);
            this.txtNameCreate.Multiline = true;
            this.txtNameCreate.Name = "txtNameCreate";
            this.txtNameCreate.Size = new System.Drawing.Size(337, 35);
            this.txtNameCreate.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(39, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enter Name";
            // 
            // lbxContentSearch
            // 
            this.lbxContentSearch.FormattingEnabled = true;
            this.lbxContentSearch.ItemHeight = 16;
            this.lbxContentSearch.Location = new System.Drawing.Point(42, 196);
            this.lbxContentSearch.Name = "lbxContentSearch";
            this.lbxContentSearch.Size = new System.Drawing.Size(337, 132);
            this.lbxContentSearch.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Search results";
            // 
            // frmCreateSearchEngine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 429);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbxContentSearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCreateNew);
            this.Controls.Add(this.txtNameCreate);
            this.Controls.Add(this.label1);
            this.Name = "frmCreateSearchEngine";
            this.Text = "frmUpdateSearchEngine";
            this.Load += new System.EventHandler(this.frmCreateSearchEngine_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCreateNew;
        private System.Windows.Forms.TextBox txtNameCreate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbxContentSearch;
        private System.Windows.Forms.Label label3;
    }
}