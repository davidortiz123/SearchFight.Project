﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entities;

namespace winSearchFight.Client
{
    public partial class frmSearching : Form 
    {
        public frmSearching()
        {
            InitializeComponent();
        }

        public SearchEngines searchEngines = new SearchEngines();

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Methods met = new Methods();
            string content = met.getSearchResult(txtSearchWord.Text);
            txtSearchResult.Text = content;
            if (string.IsNullOrEmpty(txtSearchWord.Text))
            {
                clean();
                MessageBox.Show("Incorrect word format");
            }
            else if (content == "-1")
            {
                clean();
                MessageBox.Show("Incorrect word format");
            }
            else
            {
                
            }
        }
            
        public int GetMax(int first, int second)
        {
            return first > second ? first : second;
        }

        public void clean()
        {
            txtSearchWord.Text = "";            
            txtSearchResult.Text = "";
            txtSearchWord.Focus();
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            clean();
        }

    }
}
