﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using winSearchFight.Client;

namespace Business
{
    public class Methods
    {
        public SearchEngines searchEngines = new SearchEngines();
        // ... Create new Random object.
        Random random = new Random();   
        public string getSearchResult(string word)
        {
            string[] numberWords = word.Split(' ');
            int countWords = numberWords.Length;
            string maxSearchWinner = string.Empty;
            int maxCounting = 0;
            int maxCounting1 = 0;
            int maxCounting2 = 0;
            int maxCont = 0;
            int maxCont1 = 0;
            int maxCont2 = 0;
            string textContent = "Word Search: " + word;

            if (word.StartsWith("[") && word.EndsWith("]"))
            {
                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 = random.Next(10000, 100000);
                }
                for (int i = 0; i < searchEngines.searchEngines.Count; i++)
                {
                    if (frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 > maxCounting)
                    {
                        maxCounting = frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1;
                        maxCont = i;
                    }
                }
                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Name + " | ";
                }

                for (int i = 0; i < frmCreateSearchEngine.searchEngines.searchEngines.Count; i++)
                {
                    textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[i].Counting1 + " | ";
                }

                textContent = textContent + frmCreateSearchEngine.searchEngines.searchEngines[maxCont].Name + " winner: " + word;
                word = textContent;
                //txtSearchResult.Text = "Word Search: " + txtSearchWord.Text + "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Name))
                //+ "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Counting1))
                //+ "\r\n"  
                //+ "\r\n" + searchEngines.searchEngines[maxCont].Name + " winner: " + txtSearchWord.Text;

                maxCounting = 0;
                maxCont = 0;
            }

            else if (countWords == 2)
            {
                for (int i = 0; i < searchEngines.searchEngines.Count; i++)
                {
                    searchEngines.searchEngines[i].Counting1 = random.Next(10000, 100000);
                    searchEngines.searchEngines[i].Counting2 = random.Next(20000, 50000);
                }

                for (int i = 0; i < searchEngines.searchEngines.Count; i++)
                {
                    if (searchEngines.searchEngines[i].Counting1 > maxCounting1)
                    {
                        maxCounting1 = searchEngines.searchEngines[i].Counting1;
                        maxCont1 = i;
                    }
                }

                for (int i = 0; i < searchEngines.searchEngines.Count; i++)
                {
                    if (searchEngines.searchEngines[i].Counting2 > maxCounting2)
                    {
                        maxCounting2 = searchEngines.searchEngines[i].Counting2;
                        maxCont2 = i;
                    }
                }

                word = "Word Search: " + numberWords[0] + "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Name))
                + "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Counting1)) + "\r\n" + "\r\n"
                + "Word Search: "
                + numberWords[1] + "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Name))
                + "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Counting2))
                + "\r\n"
                + "\r\n" + searchEngines.searchEngines[maxCont1].Name + " winner: " + numberWords[0]
                + "\r\n" + searchEngines.searchEngines[maxCont2].Name + " winner: " + numberWords[1];

                maxCounting1 = 0;
                maxCounting2 = 0;
            }
            else if (countWords == 1)
            {
                for (int i = 0; i < searchEngines.searchEngines.Count; i++)
                {
                    searchEngines.searchEngines[i].Counting1 = random.Next(10000, 100000);
                    searchEngines.searchEngines[i].Counting2 = random.Next(20000, 50000);
                }

                for (int i = 0; i < searchEngines.searchEngines.Count; i++)
                {
                    if (searchEngines.searchEngines[i].Counting1 > maxCounting)
                    {
                        maxCounting = searchEngines.searchEngines[i].Counting1;
                        maxCont = i;
                    }
                }

                word = "Word Search: " + word + "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Name))
                + "\r\n" + string.Join(" | ", searchEngines.searchEngines.Select(x => x.Counting1))
                + "\r\n"
                + "\r\n" + searchEngines.searchEngines[maxCont].Name + " winner: " + word;

                maxCounting = 0;
                maxCont = 0;
            }
            else
            {
                return "Error";
            }

            return textContent;
        }
    }
}
