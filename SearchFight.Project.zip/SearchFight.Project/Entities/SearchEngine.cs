﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class SearchEngine
    {
        public string Name { get; set; }
        public int Counting1 { get; set; }
        public int Counting2 { get; set; }
        public SearchEngine(string _name)
        {
            Name = _name;
        }        
    }

    public class SearchEngines
    {
        public List<SearchEngine> searchEngines { get; set; }

        // Initialize search engine list.
        public SearchEngines()
        {
            searchEngines = new List<SearchEngine>();
            searchEngines.Add(new SearchEngine("MSN"));
            searchEngines.Add(new SearchEngine("Google"));
                
        }
    }
}
